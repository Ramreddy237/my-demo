import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StepService {

  constructor(private httpClient: HttpClient) { }

  fetchData(): Observable<any> {
    const url = 'https://uqnzta2geb.execute-api.us-east-1.amazonaws.com/default/FrontEndCodeChallenge';
    return this.httpClient.get(url).pipe(res => res);
  }
}

