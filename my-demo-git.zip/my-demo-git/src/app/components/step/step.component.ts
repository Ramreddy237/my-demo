import { Component, Input, OnInit } from '@angular/core';
import { OrderByPipe } from 'src/pipes/order-by.pipe';

@Component({
  selector: 'app-step',
  templateUrl: './step.component.html',
  styleUrls: ['./step.component.scss']
})
export class StepComponent implements OnInit {
  @Input() step: any;

  latestContent: any;

  constructor(private orderByPipe: OrderByPipe) { }

  ngOnInit() {
    this.step.stepNumber = this.step.stepNumber.padStart(2, 0);
    this.latestContent = this.orderByPipe.transform(this.step.versionContent, 'effectiveDate', false)[0];
  }
}
