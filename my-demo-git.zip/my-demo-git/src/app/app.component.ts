import { Component, OnInit } from '@angular/core';
import { StepService } from 'src/services/step.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'my-demo';
  steps: any;

  constructor(private stepService: StepService) { }

  ngOnInit() {
    this.stepService.fetchData().subscribe(res => {
      this.steps = res;
    })
  }
}
