import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StepService } from 'src/services/step.service';
import { HttpClientModule } from '@angular/common/http';
import { OrderByPipe } from 'src/pipes/order-by.pipe';
import { StepComponent } from './components/step/step.component';

@NgModule({
  declarations: [
    AppComponent,
    StepComponent,
    OrderByPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  exports: [OrderByPipe],
  providers: [StepService, OrderByPipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
